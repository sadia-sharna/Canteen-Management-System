/*
	author: S. M. Shahriar Nirjon
	last modified: August 8, 2008
*/
# include "iGraphics.h"


	//double xco=-5, yco=-5;
	double cx=200,cy=200,r=10;
	double cx2=200,cy2=200,r2=10;
    double cx3=200,cy3=200,r3=10;
	double cx4=200,cy4=200,r4=10;
	int i,t,f=0,f2=0,f3=0,f4=0;
/* 
	function iDraw() is called again and again by the system.
*/
void iDraw()
{
	
	//place your drawing codes here	
	iClear();
	//iFilledCircle(xco, yco, 5);
	//iText(300,300 , "WELCOME TO THE HELL", GLUT_BITMAP_HELVETICA_18);
	iSetColor(255,0,0);
	//double x1=100,y1=100,x2=200,y2=100;

	//int i;
	//for(i=0;i<5;i++)
	//{
	//iLine(x1,y1,x2,y2);
	iFilledCircle(cx,cy,r);
	iSetColor(0,255,0);
	iFilledCircle(cx2,cy2,r2);
	iSetColor(0,0,255);
	iFilledCircle(cx3,cy3,r3);
	iSetColor(255,0,0);
	iFilledCircle(cx4,cy4,r4);

	//x1=x2+10;
	
	//x2=(x2+100);
	//cx=(x1+x2)/2;
	//if(i%2==0)
		//iSetColor(250,0,0);
	//else
		//iSetColor(0, 0 , 250);
	
	//}
	
	
}

/* 
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//xco=mx;
	//yco=my;
	//place your codes here
}

/* 
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{
	//if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	//{
		//printf("left button clicked at %d and %d\n", mx, my);
		//place your codes here	
	//}
	//if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	//{
		//printf("Right button clicked at %d and %d\n", mx, my);
		//place your codes here	
	//}
}
/*iPassiveMouseMove is called to detect and use 
the mouse point without pressing any button */

void iPassiveMouseMove(int mx,int my)
{
	//place your code here
	
 
	//xco = mx;
	//yco = my;
	//if(mx== 2){}        /*Something to do with mx*/
	//else if(my== 2){}   /*Something to do with my*/
 
}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed. 
*/
void iKeyboard(unsigned char key)
{
	//if(key == 'q')
	//{
		//do something with 'q'
	//}
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use 
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6, 
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12, 
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP, 
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT 
*/
void iSpecialKeyboard(unsigned char key)
{

	if(key == GLUT_KEY_END)
	{
		exit(0);	
	}
	//place your codes for other keys here
}

void func(void)
{
//code of the task that will be repeated.
	
	if(cy>=400) 
		{
		f=1;
	   }
	if(f==1 && cy!=200) 
	{
	cy--;
	}
		
	else 
		{
			cy++;
			f=0;
	    }
	if(cx2>=400) f2=1;
	if(f2==1 && cx2!=200) cx2--;
	else
	{
		cx2++;
		f2=0;
	}
	if(cx3<=0) f3=1;
	if(f3==1 && cx3!=200) cx3++;
	else 
	{
		f3=0;
		cx3--;
	}

	if(cy4<=0) f4=1;
	if(f4==1 && cy4!=200) cy4++;
	else 
	{
		f4=0;
		cy4--;
	}
}

int main()
{
	
	t = iSetTimer(10, func);
	//place your own initialization codes here. 
	iInitialize(400, 400, "CSE !st year 1st semester A2-1");
	
	return 0;
}